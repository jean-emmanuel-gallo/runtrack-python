num1 = 3 

num2 = 14 

result = num1 * num2 

print(result)