n ='ma-string'

m = 'Je suis une variable'

print(n, m)
