print(10*3)
print(10-3)