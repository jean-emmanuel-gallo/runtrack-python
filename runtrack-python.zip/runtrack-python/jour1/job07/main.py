num1 = 40

num2 = 2

result = num1 + num2

print(result)